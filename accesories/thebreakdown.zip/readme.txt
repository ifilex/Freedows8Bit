==========================================================================
           The Breakdown - A Snack-Sized Adventure Game (v0.99)
==========================================================================

                              TABLE OF CONTENTS

                           1. What's it all about
                           2. How to play
                           3. System Requirements
                           4. Known bugs
                           5. Contact info
                           6. Random Ramblings
                           x. Disclaimer


--------------------------------------------------------------------------
1. What's it all about
--------------------------------------------------------------------------

The Breakdown is an old school, point'n click adventure game. Like the
ones made by Lucasarts (but not as cool). From your childhood, remember? 
If you don't, read the following:

Adventure games are all about exploration and solving puzzles. By 
examining everything and picking up everything you can, you raise your 
odds to achieve success. That's true in real life, too.

After the intro it will become clear, that you're playing the pointy 
haired main character, and your objective is to get to your home town and
cash the winning lottery ticket in time.

The Breakdown is freeware, which means you can play and distribute it for
free. You're not allowed to make money for distributing it, though. If you
want to add it on a compilation cd of some sort, you have to ask my 
permission.

The game was developed with AGAST (Adventure Game Authoring System) made 
by Russell Bailey and Todd Zankich. 


--------------------------------------------------------------------------
2. How to Play
--------------------------------------------------------------------------

You control the game with you mouse. When the cursor is a gray arrow, 
left-clicking somewhere tells the main character to walk there. 

You can also choose an action to perform from the menu at the top of the 
screen. You have three action icons: 'Look At', 'Talk To' and 'Take/Use'. 
Left click on the icons and you can perform the action on objects on the 
screen or items in your inventory.

Right-clicking the mouse sets the icon in its default state, i.e. 
'Walk To.'

Next to the action icons is your inventory. Things you pick up will appear 
there. You can try to use that stuff on any objects in the game and even 
with each other. 

You can save your progress if you don't want to play the game through one 
go. To view the save/load-menu, just press esc.

To make the gaming experience a little bit fluider, you can use keyboard 
shortcuts for the actions. The shortcut-keys will be visible under the 
action icons.

Another convenience feature is that you can skip the dialogue lines by 
pressing left mouse button or the dot "." key. Yes, the use of the dot key 
is a homage to Lucasarts. I'll bet they can't keep their pants at the ol' 
Lucas ranch because of this feature.


--------------------------------------------------------------------------
3. System Requirements 
--------------------------------------------------------------------------

Its a bit hazy to me what the optimal configuration for The Breakdown is. 
I tested it with my folks' old steam engine computer, so let's say that it 
is the minimum requirement for the game. Here you go:

Minimum configuration:
 * Windows 95/98/98SE/ME/NT/2000/XP
 * Pentium II / 350MHz
 * 48MB of RAM
 * 20MB of hard drive
 * DirectX 7.0 compatible sound and video cards
 * DirectX 7.0
 * A mouse

Recommended configuration:
 * Anything better than the minimum configuration.


--------------------------------------------------------------------------
4. Known Bugs 
--------------------------------------------------------------------------

Because of the way AGAST works, some display adapters cause problems with 
the game. There's not much I can do about those bugs. What YOU can do, 
though, is to make sure you have the latest display drivers and DirectX 
version. It'll go a long way in ensuring that the game runs smoothly.

Also, if the screen is garbled or other display related bugs occur, you 
can try to decrease the amount of hardware acceleration your windows is 
set up with. In most Windowses, you can find the acceleration slider from: 
Display Properties / Settings / Advanced / Troubleshoot. If you set the 
acceleration to a small, maybe minimum,  value the bugs should go away. 

At the moment AGAST has quite weird path finding and scaling algorithms, 
so it's not humanly possible to retain correct scaling of the character at
all times. And sometimes the path finding acts up, which results in the 
walking character popping to full size (or flickering). I can't do 
anything about that (if whining and crying don't count) and I can only 
hope that in some future version of AGAST this has been fixed. Sorry.

If you find any other bugs, please report them to me. You can find my 
contact info in the.. contact info section. Yes, that's right.


--------------------------------------------------------------------------
5. Contact Info
--------------------------------------------------------------------------

I'm always interest in feedback. How much did you hate the game? Will you 
dedicate your life to bringing me to justice? Or did you maybe enjoy the 
game, just a little bit, don't tell anyone, ever?

You can either e-mail me at jtu@iki.fi or check out The Breakdown website 
at http://thebreakdown.adventuredevelopers.com - if the site might be down 
someday, I have an backup address which should work indefinitely. 
The backup address is: http://www.iki.fi/jtu/thebreakdown/ 

If you want to achieve near real-time communication with me, you can use 
ICQ. My ICQ number is 2026664.

The Breakdown's great musical score was composed and performed by a 
musical maestro who goes by the name of Aleksi Munter. You can get in 
touch with him by e-mail at amunter@st.jyu.fi - he's probably more than 
happy to receive the fat checks you're about to offer him for his talent.
Aleksi's ICQ number is 58533865.

The homepage of AGAST can be found at http://www.allitis.com (..In case 
you forgot, AGAST is the scripting language The Breakdown was made with.)


--------------------------------------------------------------------------
6. Random Ramblings
--------------------------------------------------------------------------

First, I'd like to say that this is version 0.99 of the game. Mainly this
is so, because of a technical deficiency in AGAST. In short it is not 
possible to control the music or make it loop perferctly. So after a new
AGAST version is released, expect the 1.00 version of The Breakdown, too.

Now, let me get to my random ramblings.

A wise fellow, who stole and refined the idea of another wise fellow, said 
that you have to make ten bad games before you can make a good one. The 
Breakdown is more or less my third game. The first two were made about ten 
years ago with Turbo Pascal, the other being a hangman clone and the other 
a football game with ansi graphics. 

I'm still quite satisfied on how this game turned out to be. It's not 
nearly as good as I hoped it would be, but it's better than the first two. 
The biggest thing bugging me in The Breakdown is that it's so short and as 
a result from this the story is thin. But hey, it's free!

As I made this game all by myself (excluding the wonderful music by Aleksi 
Munter), the amount of work was quite frankly overwhelming. I 
underestimated the workload and therefore almost went ballistic and 
formatted my and my neighbor's hard drives, but was somehow able to 
control myself and finish the game - although very much late of my 
original deadline.

The burnout will be seen in the game as somewhat minimalistic animations 
and as some rough edges here and there. I would have liked to add many 
more small animations and details both on the main character and the 
backgrounds, but there was neither the time nor the energy. It's been 
educational, and for my next game I'll lure in some unsuspecting help.

Thanks for listening. Go play the game and send me a eMail if you liked it. 
Or hated it. Or went ballistic and formatted your and your neighbour's 
hard drives.


--------------------------------------------------------------------------
x. Disclaimer 
--------------------------------------------------------------------------

I won't bother myself with a long and tedious disclaimer, since nobody 
reads nor likes them. So, briefly: Anything this game might do to you or 
anything near you is your headache. It shouldn't do anything bad, but you 
never know.

You run the game voluntarily. I didn't make you do it and I will not 
accept responsibility for anything. Ok, maybe for the bad jokes, but 
nothing beyond that.

The Breakdown is freeware. You're entitled to play and distribute if for 
free, but you're not allowed to make money from it. Contact me, if you 
wish to discuss distributing it on compilation cd's or other mediums which 
have a payment of some sort involved.