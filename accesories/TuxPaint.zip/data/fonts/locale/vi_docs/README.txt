README.txt for "tuxpaint-ttf-vietnamese"
Vietnamese TrueType Font (TTF) for Tux Paint

Bill Kendrick
bill@newbreedsoftware.com
http://www.newbreedsoftware.com/tuxpaint/

April 15, 2004 - April 15, 2004


This font is required to run Tux Paint in Vietnamese.
(e.g., with the "--lang vietnamese" option)

To install, run "make install" as the superuser ('root').
The font file will be placed in the /usr/share/tuxpaint/fonts/locale/ directory.

