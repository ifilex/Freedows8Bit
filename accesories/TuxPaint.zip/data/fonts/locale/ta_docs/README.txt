README.txt for "tuxpaint-ttf-korean"
Korean TrueType Font (TTF) for Tux Paint

Bill Kendrick
bill@newbreedsoftware.com
http://www.newbreedsoftware.com/tuxpaint/

December 5, 2002 - December 5, 2002


This font is required to run Tux Paint in Korean.
(e.g., with the "--lang korean" option)

To install, run "make install" as the superuser ('root').
The font file will be placed in the /usr/share/tuxpaint/fonts/ directory.

