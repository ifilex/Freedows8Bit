Please see "docs/README.txt"
